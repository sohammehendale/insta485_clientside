"""Views, one for each Insta485 page."""
from insta485.views.index import show_index
